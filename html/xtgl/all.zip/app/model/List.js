Ext.define('proauthXtgl.model.List', {
    extend: 'Ext.data.Model',
    fields: ['username', 'dispname', 'email', 'addtime', 'level','email','logcount','userid','opt','groupname','role','syjm','groupid','optid','useflags','levelname','fcode','fac','facid']
});