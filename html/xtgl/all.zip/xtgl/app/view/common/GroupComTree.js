Ext.define('LanProcy.view.common.GroupComTree' ,{
  extend: 'Ext.window.Window',
  alias : 'widget.groupcomtree',
  
  title: "ѡ���·����Ż��߼����",
  width: 200,
  height:300,
  modal: true,
 // autoShow: true,

  initComponent: function() {
    
   	this.items = [{
    	xtype: 'treepanel',
    	frame: true,
    	padding: 5,
      height:300,
    	rootVisible: false,
    	store:Ext.create('Ext.data.TreeStore', {
   	    fields:['id','text','pid'],
        proxy: {
          type: 'ajax',
          url: '/pronline/Msg?FunName@lanTree_depComp'
        },
        root: {
          text: 'ȫ��',
          id: '',
          expanded: true
        },
        folderSort: true
		  })
	  }],
	  
	  this.buttons = [
   		{text:"����",action:'save'},
   		{text:"�ر�",action:'close',scope: this,handler:this.close}
   	];

    this.callParent(arguments);
  }
});