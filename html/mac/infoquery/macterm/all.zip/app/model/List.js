Ext.define('proauthRzAuthlog.model.List', {
    extend: 'Ext.data.Model',
    fields: [ 'mac', 'stime', 'rssi', 'servicename', 'dispname', 'ssid', 'apmac', 'channel', 'security', 'servicecode', 'apname', 'longitude', 'latitude', 'vtype', 'vname', 'termtype', 'apssid', 'xpos', 'ypos']
});
  
