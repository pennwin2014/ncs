Ext.define('proauthRzAuthlog.model.List', {
    extend: 'Ext.data.Model',
    fields: [ 'authflag', 'ssid', 'servicename', 'channel', 'security', 'stime', 'apmac', 'hotspotfirm', 'rssi', 'longitude',  'latitude', 'servicecode', 'apname', 'xpos','ypos']
});
  
