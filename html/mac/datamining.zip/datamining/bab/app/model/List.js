Ext.define('proauthRzAuthlog.model.List', {
    extend: 'Ext.data.Model',
    fields: ['taskname','result','taskdesc', 'maccount', 'reporttime','cid','mac','servcount','groupname']
});
  
