Ext.define('proauthRzAuthlog.model.List', {
    extend: 'Ext.data.Model',
    fields: ['vara','checked1', 'rolename', 'roldispname']
  });
