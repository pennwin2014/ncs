Ext.define('proauthMobileAccount.model.macModel', {
    extend: 'Ext.data.Model',
    fields: ['sid', 'mac','flags','gid','gname','name','wtype','waddr','level','dateid','countlimit','apname']
});