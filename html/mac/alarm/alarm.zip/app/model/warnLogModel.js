Ext.define('proauthMobileAccount.model.warnLogModel', {
    extend: 'Ext.data.Model',
    fields: ['sid', 'mac','flags','servicecode','servicename','stime','rulename','message','opname','optime','cid','msid','ruleid']
});