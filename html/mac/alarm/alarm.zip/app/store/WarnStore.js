Ext.define('proauthMobileAccount.store.WarnStore', {
  extend: 'Ext.data.Store',
  id:'WarnStore',
  pageSize: 40,
  model: 'proauthMobileAccount.model.macModel',
 remoteSort: true,
  proxy: {
    type: 'ajax',
    url : '/pronline/Msg?FunName@ncsSys_WarnNoty',
    reader: {
      type: 'json',
      root: 'eimdata',
      totalProperty: 'totalCount'
    },
     simpleSortMode: true
  },
   sorters: {
            property: 'sid',
            direction: 'DESC'
        }
});
