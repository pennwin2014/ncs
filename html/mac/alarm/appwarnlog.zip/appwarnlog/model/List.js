Ext.define('proauthMobileAccount.model.List', {
    extend: 'Ext.data.Model',
    fields: ['sid','casecode', 'servicecode','mac','stime','msid','ruleid','message','casetype', 'caseclass', 'groupid','casedept','casedate','addby','flags','cmemo','lasttime','expiretime','cobj','cobjid','pcount','wcount','warnlasttime']
});