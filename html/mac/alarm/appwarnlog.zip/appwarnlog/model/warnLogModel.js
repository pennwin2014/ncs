Ext.define('proauthMobileAccount.model.warnLogModel', {
    extend: 'Ext.data.Model',
    fields: ['sid','mac','termtype','stime','servicename','address','rssi','vtype','vname','ssid','apname','apmac','channel','security','xpos','ypos','longitude','latitude','flags']
});