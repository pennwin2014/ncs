Ext.define('proauthMobileAccount.model.macModel', {
    extend: 'Ext.data.Model',
    fields: ['sid', 'mac','flags','termtype','address','rssi','apname','apmac','channel','security','xpos','ypos','longitude','latitude']
});